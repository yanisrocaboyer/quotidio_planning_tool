<?php
require_once './functions/connection.php';

$user = verif_token($_SESSION["token"]);
$access = $user["type"];
if (!isset($_SESSION["token"]) || empty($_SESSION["token"]) || !$access || $access != "admin") {
    include "./page/error/403.php";
}
else {

$TITLE = "Quotidio Planning - Admin";
?>
<div class="dashboard">
    <div class="dashboard-content">
        <?php include 'components/admin/sidebar.php' ?> 
        <div class="content">
            <div class="ml-5 mt-5">
                <div class="flex">
                    <h1 class="text-2xl">👋 Bonjour, <?php echo $user["identifiant"] ?></h1>
                </div>
                <h2 class="mt-2 mb-2">Praticien en attente de validation</h2>
                <?php
                $pending_praticiens = get_praticiens("pending");
                foreach($pending_praticiens as $praticien) {
                    ?>
                    <a href="/page/admin/user_gestion.php?type=praticien&user_id=<?php echo $praticien['id'] ?>">
                        <div class="partenaire_card">
                            <div>
                                <img src="/assets/unknown.jpg" alt="Unknown User" class="rounded-md" width="50px" draggable="false">
                            </div>
                            <div class="ml-3 leading-none mt-auto mb-auto">
                                <p class="text-lg/4"><?php echo $praticien["name"] ?> <?php echo $praticien["surname"] ?></p>
                                <p class="text-sm/4"><?php echo $praticien["email"] ?></p>
                            </div>
                        </div>
                    </a>
                    <?php
                }
                ?>
            </div>
        </div>
    </div>
</div>
<?php
}
?>
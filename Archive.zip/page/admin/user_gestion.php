<?php
require_once './functions/connection.php';

$user = verif_token($_SESSION["token"]);
$access = $user["type"];
if (!isset($_SESSION["token"]) || empty($_SESSION["token"]) || !$access || $access != "admin") {
    include "./page/error/403.php";
}
else {

$TITLE = "Quotidio Planning - Admin";
$type = $_GET["type"];
$user_id = $_GET["user_id"];
?>
<div class="dashboard">
    <div class="dashboard-content">
        <?php include 'components/admin/sidebar.php' ?> 
        <div class="content">
            <div class="ml-5 mt-5">
                <div class="flex">
                    <h1 class="text-2xl">👋 Bonjour, <?php echo $user["identifiant"] ?></h1>
                </div>
                <?php
                if ($type == "praticien"){
                    $praticien = get_praticien($user_id);
                    ?>
                    <h2>Gestion de <?php echo $praticien["surname"] ?> <?php echo $praticien["name"] ?></h2>
                    <h3>Informations:</h3>
                    <p>Nom: </p>
                    <p>Prénom: </p>
                    p{}
                    <?php
                }
                ?>
            </div>
        </div>
    </div>
</div>
<?php
}
?>